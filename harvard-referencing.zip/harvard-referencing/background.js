chrome.action.onClicked.addListener(t => {
    chrome.tabs.sendMessage(t.id, { action: "TOGGLE" }).catch(e => 
        console.log("Script not ready. Refresh the ReadTheory page.")
    );
});