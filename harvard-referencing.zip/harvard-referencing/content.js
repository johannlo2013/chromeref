function validateKeyWithAPI(key, cb) {
    fetch("https://doofus.cc/validate", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ key })
    })
    .then(res => {
        if (!res.ok) throw new Error("HTTP " + res.status);
        return res.json();
    })
    .then(data => cb(data.valid === true))
    .catch(err => {
        console.error("Validation request failed:", err);
        cb(false);
    });
}

function runScript() {

let A=[],m=0,w=null,d=!1,autoMode=!1,$ans,$idx;

{
    const s=document.createElement("script");
    s.src=chrome.runtime.getURL("inject.js");
    s.onload=function(){this.remove();};
    (document.head||document.documentElement).appendChild(s);
}

window.addEventListener("message",e=>{
    if(e.source!==window||e.data?.type!=="INTERCEPTED_RESPONSE")return;
    try{
        const n=[];
        (function o(e){
            if(Array.isArray(e)){for(let i=0;i<e.length;i++)o(e[i]);return;}
            if(!e||typeof e!=="object")return;
            if(e.correct_answer_id!==undefined){
                const arr=e.answers||e.options||e.choices||[];
                const ids=new Array(arr.length);
                for(let i=0;i<arr.length;i++)ids[i]=arr[i].id||arr[i].answer_id||arr[i].option_id||0;
                ids.sort((a,b)=>a-b);
                const i=ids.indexOf(e.correct_answer_id);
                n.push({q:e.id||e.question_id||e.item_id||0,a:i>=0?String.fromCharCode(65+i):"?"});
            }
            const vals=Object.values(e);
            for(let i=0;i<vals.length;i++)o(vals[i]);
        })(JSON.parse(e.data.body));
        if(n.length){
            n.sort((a,b)=>a.q-b.q);
            if(A.length!==n.length||A.some((v,i)=>v.q!==n[i].q)){A=n;m=0;}
            U();
        }
    }catch{}
});

const ans=()=>A[2*m]??A.at(-1);

function U(){
    if(!$idx)return;
    const a=ans();
    $idx.innerText=`${m+1} / ${Math.ceil(A.length/2)||"-"}`;
    $ans.innerText=a?.a??"-";
}

function waitFor(selector, { timeout = 10000, check = el => !!el } = {}) {
    return new Promise((resolve, reject) => {
        const start = performance.now();

        function tick() {
            const el = document.querySelector(selector);
            if (el && check(el)) {
                resolve(el);
                return;
            }
            if (performance.now() - start > timeout) {
                reject(new Error(`Timeout waiting for ${selector}`));
                return;
            }
            requestAnimationFrame(tick);
        }

        tick();
    });
}

async function attemptAuto(){
    if(!autoMode)return;
    if(!A.length){await sleep(2000);autoMode&&attemptAuto();return;}
    const n=ans();
    if(!n||n.a==="?")return;
    document.querySelectorAll(".student-quiz-page__answer")[n.a.charCodeAt(0)-65]?.click();
    await sleep(3500);if(!autoMode)return;
    document.querySelector(".student-quiz-page__question-submit")?.click();
    await sleep(700);if(!autoMode)return;
    document.querySelector(".student-quiz-page__question-next")?.click();
    await sleep(500);if(!autoMode)return;
    m++;U();attemptAuto();
}

const sleep=ms=>new Promise(r=>setTimeout(r,ms));

const K=e=>{
    if(e.target.tagName==="INPUT"||e.target.tagName==="TEXTAREA")return;
    if(e.key==="ArrowLeft"){if(m>0){m--;popAns();U();}}
    else if(e.key==="ArrowRight"){m++;popAns();U();}
};

let D=!1,X,Y;
const M=e=>{if(D){w.style.left=e.clientX-X+"px";w.style.top=e.clientY-Y+"px";w.style.bottom="auto";}};
const Z=()=>{D=!1;};

function closeWidget(){
    w?.remove();w=null;autoMode=!1;$ans=$idx=null;
    window.removeEventListener("keydown",K);
    window.removeEventListener("mousemove",M);
    window.removeEventListener("mouseup",Z);
}

function injectStyles(){
    if(document.getElementById("mr-styles"))return;
    const style=document.createElement("style");
    style.id="mr-styles";
    style.textContent=`
        #mr-widget {
            position:fixed; bottom:20px; left:20px; z-index:999999;
            width:350px;
            background:linear-gradient(160deg,#7e685e 0%,#836965 55%,#94786e 100%);
            border:1px solid rgba(223,215,203,0.16);
            border-radius:20px;
            padding:14px;
            color:#dfd7cb;
            font-family:'Inter','Segoe UI','SF Pro Display',system-ui,sans-serif;
            text-align:center;
            box-shadow:0 12px 40px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.03) inset;
            cursor:move;
            user-select:none;
        }
        #mr-widget.light {
            background:linear-gradient(160deg,#dfd7cb 0%,#d6ccbf 100%);
            border-color:rgba(126,104,94,0.22);
            color:#7e685e;
            box-shadow:0 8px 32px rgba(126,104,94,0.12), 0 0 0 1px rgba(255,255,255,0.75) inset;
        }


        #mr-topbar {
            display:flex; justify-content:space-between; align-items:center;
            margin-bottom:10px;
        }
        #mr-wordmark {
            font-size:14px; font-weight:800;
            opacity:0.42;
        }
        .mr-icon-btn {
            background:rgba(223,215,203,0.08);
            border:1px solid rgba(223,215,203,0.12);
            border-radius:9px; color:inherit; cursor:pointer;
            font-size:13px; line-height:1; padding:6px 8px;
            transition:background 0.15s,transform 0.1s;
        }
        .mr-icon-btn:hover{background:rgba(223,215,203,0.16);transform:scale(1.1);}
        #mr-widget.light .mr-icon-btn{background:rgba(126,104,94,0.08);border-color:rgba(126,104,94,0.12);}
        #mr-widget.light .mr-icon-btn:hover{background:rgba(126,104,94,0.14);}
        #mr-close{border-color:rgba(167,139,129,0.35);}
        #mr-close:hover{background:rgba(148,120,110,0.26)!important;border-color:rgba(167,139,129,0.65);}


        #mr-ans-wrap {
            position:relative;
            margin:10px 0 12px;
        }
        #mr-ans {
            font-size:72px; font-weight:900; line-height:1;
            color:#dfd7cb;
            text-shadow:0 0 24px rgba(223,215,203,0.18);
            transition:color 0.25s,text-shadow 0.25s;
            cursor:default;
            letter-spacing:-3px;
        }
        #mr-widget.light #mr-ans{
            color:#836965;
            text-shadow:0 0 16px rgba(131,105,101,0.18);
        }
        #mr-ans.mr-pop{animation:mr-pop 0.2s cubic-bezier(.34,1.56,.64,1);}
        @keyframes mr-pop{0%{transform:scale(1)}50%{transform:scale(1.24)}100%{transform:scale(1)}}


        .mr-rule {
            height:1px;
            background:linear-gradient(90deg,transparent,rgba(223,215,203,0.22),transparent);
            margin:8px 0;
        }
        #mr-widget.light .mr-rule{
            background:linear-gradient(90deg,transparent,rgba(126,104,94,0.18),transparent);
        }


        #mr-nav {
            display:flex; align-items:center; justify-content:space-between; gap:6px;
        }
        .mr-nav-btn {
            background:rgba(223,215,203,0.07);
            border:1px solid rgba(223,215,203,0.12);
            border-radius:10px; color:inherit; cursor:pointer;
            font-size:18px; font-weight:700;
            width:42px; height:34px;
            display:flex; align-items:center; justify-content:center;
            transition:background 0.15s,transform 0.1s;
            flex-shrink:0;
        }
        .mr-nav-btn:hover{background:rgba(167,139,129,0.22);transform:scale(1.08);}
        #mr-widget.light .mr-nav-btn{background:rgba(126,104,94,0.06);border-color:rgba(126,104,94,0.12);}
        #mr-widget.light .mr-nav-btn:hover{background:rgba(148,120,110,0.14);}
        #mr-idx{font-size:12px;font-weight:700;opacity:0.5;flex:1;letter-spacing:0.03em;}


        #mr-auto {
            margin-top:10px; width:100%; padding:10px 0;
            border-radius:11px; border:1px solid rgba(223,215,203,0.12);
            background:rgba(223,215,203,0.06);
            color:inherit; font-size:13px; font-weight:800;
            cursor:pointer;
            transition:background 0.2s,border-color 0.2s,color 0.2s,box-shadow 0.2s;
        }
        #mr-auto:hover{background:rgba(223,215,203,0.11);}
        #mr-auto.on{
            background:linear-gradient(135deg,#a78b81 0%,#94786e 100%);
            border-color:rgba(223,215,203,0.22); color:#fff;
            box-shadow:0 0 16px rgba(148,120,110,0.28);
        }
        #mr-widget.light #mr-auto{background:rgba(126,104,94,0.06);border-color:rgba(126,104,94,0.12);}
        #mr-widget.light #mr-auto:hover{background:rgba(126,104,94,0.1);}
    `;
    document.head.appendChild(style);
}

function openWidget(){
    if(w) return;

    injectStyles();

    w=document.createElement("div");
    w.id="mr-widget";
    if(d)w.classList.add("light");

    w.onmousedown=e=>{
        if(e.target.closest("button"))return;
        D=!0;const b=w.getBoundingClientRect();X=e.clientX-b.left;Y=e.clientY-b.top;
    };

    const topbar=document.createElement("div");
    topbar.id="mr-topbar";

    const themeBtn=document.createElement("button");
    themeBtn.className="mr-icon-btn";themeBtn.id="mr-theme";
    themeBtn.innerText=d?"☀️":"🌙";

    const wordmark=document.createElement("span");
    wordmark.id="mr-wordmark";wordmark.innerText="morley decimator";

    const closeBtn=document.createElement("button");
    closeBtn.className="mr-icon-btn";closeBtn.id="mr-close";
    closeBtn.innerText="✕";

    topbar.append(themeBtn,wordmark,closeBtn);

    const ansWrap=document.createElement("div");
    ansWrap.id="mr-ans-wrap";
    $ans=document.createElement("div");
    $ans.id="mr-ans";$ans.innerText="-";
    ansWrap.append($ans);

    const rule=document.createElement("div");
    rule.className="mr-rule";

    const nav=document.createElement("div");
    nav.id="mr-nav";

    const prevBtn=document.createElement("button");
    prevBtn.className="mr-nav-btn";prevBtn.innerText="‹";

    $idx=document.createElement("span");
    $idx.id="mr-idx";$idx.innerText="Refresh the page";

    const nextBtn=document.createElement("button");
    nextBtn.className="mr-nav-btn";nextBtn.innerText="›";

    nav.append(prevBtn,$idx,nextBtn);

    const autoBtn=document.createElement("button");
    autoBtn.id="mr-auto";autoBtn.innerText="🤖 Auto Answer: OFF";

    w.append(topbar,ansWrap,rule,nav,autoBtn);
    document.body.appendChild(w);

    themeBtn.onclick=e=>{
        e.stopPropagation();d=!d;
        w.classList.toggle("light",d);
        themeBtn.innerText=d?"☀️":"🌙";
    };
    closeBtn.onclick=e=>{e.stopPropagation();closeWidget();};
    prevBtn.onclick=e=>{e.stopPropagation();if(m>0){m--;popAns();U();}};
    nextBtn.onclick=e=>{e.stopPropagation();m++;popAns();U();};
    autoBtn.onclick=e=>{
        e.stopPropagation();autoMode=!autoMode;
        autoBtn.innerText=autoMode?"🤖 Auto Answer: ON":"🤖 Auto Answer: OFF";
        autoBtn.classList.toggle("on",autoMode);
        if(autoMode)attemptAuto();
    };

    window.addEventListener("keydown",K);
    window.addEventListener("mousemove",M);
    window.addEventListener("mouseup",Z);
    U();
}

chrome.runtime.onMessage.addListener(e=>{
    if(e.action!=="TOGGLE")return;
    if(w){closeWidget();return;}
    openWidget();
});

openWidget();

function popAns(){
    if(!$ans)return;
    $ans.classList.remove("mr-pop");
    void $ans.offsetWidth;
    $ans.classList.add("mr-pop");
}

}

chrome.storage.local.get(["mdToken"], function(result) {
    const mdToken = result.mdToken;

    if (!mdToken || mdToken === "undefined") {
        const enteredKey = prompt("Enter key:");
        if (!enteredKey) return;

        validateKeyWithAPI(enteredKey, function(valid) {
            if (!valid) return;

            chrome.storage.local.set({ mdToken: enteredKey }, function() {
                runScript();
            });
        });

        return;
    }

    validateKeyWithAPI(mdToken, function(valid) {
        if (!valid) {
            chrome.storage.local.remove(["mdToken"]);
            return;
        }

        runScript();
    });
});