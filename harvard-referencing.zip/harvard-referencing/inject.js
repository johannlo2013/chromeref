const _f = window.fetch;
window.fetch = async function(...a) {
    const r = await _f.apply(this, a);
    r.clone().text().then(b => window.postMessage({type:"INTERCEPTED_RESPONSE",url:r.url,body:b},"*")).catch(()=>{});
    return r;
};